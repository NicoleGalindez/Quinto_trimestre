import modelos from "../modelo/mimodelo.js"; // Asegúrate de que la ruta sea correcta

const Instructor = modelos.Instructor;

// Controlador para obtener todos los instructores
export const obtenerTodosLosInstructores = async (req, res) => {
  try {
    const instructores = await Instructor.findAll();
    res.json(instructores);
  } catch (error) {
    res.status(500).json({
      message: "Error al obtener los instructores",
      error: error.message,
    });
  }
};

// Controlador para obtener un instructor por ID
export const obtenerInstructorPorID = async (req, res) => {
  const { id } = req.params;
  try {
    const instructor = await Instructor.findByPk(id);
    if (instructor) {
      res.json(instructor);
    } else {
      res
        .status(404)
        .json({ message: `No se encontró un instructor con ID ${id}` });
    }
  } catch (error) {
    res.status(500).json({
      message: "Error al obtener el instructor",
      error: error.message,
    });
  }
};

// Controlador para crear un nuevo instructor
export const crearInstructor = async (req, res) => {
  const nuevoInstructor = req.body;
  try {
    const instructorCreado = await Instructor.create(nuevoInstructor);
    res.status(201).json(instructorCreado);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error al crear el instructor", error: error.message });
  }
};
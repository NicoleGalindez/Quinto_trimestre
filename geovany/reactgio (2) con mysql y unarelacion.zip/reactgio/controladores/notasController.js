import modelos from "../modelo/mimodelo.js"; // Asegúrate de que la ruta sea correcta

const Notas = modelos.Notas;

// Controlador para obtener todas las notas
export const obtenerTodasLasNotas = async (req, res) => {
  try {
    const notas = await Notas.findAll();
    res.json(notas);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error al obtener las notas", error: error.message });
  }
};

// Controlador para obtener una nota por ID
export const obtenerNotaPorID = async (req, res) => {
  const { id } = req.params;
  try {
    const nota = await Notas.findByPk(id);
    if (nota) {
      res.json(nota);
    } else {
      res.status(404).json({ message: `No se encontró una nota con ID ${id}` });
    }
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error al obtener la nota", error: error.message });
  }
};

// Controlador para crear una nueva nota
export const crearNota = async (req, res) => {
  const nuevaNota = req.body;
  try {
    const notaCreada = await Notas.create(nuevaNota);
    res.status(201).json(notaCreada);
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error al crear la nota", error: error.message });
  }
};
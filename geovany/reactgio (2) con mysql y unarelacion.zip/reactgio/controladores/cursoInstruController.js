import modelos from "../modelo/mimodelo.js"; // Asegúrate de que la ruta sea correcta

const Curso_Instru = modelos.Curso_Instru;

// Controlador para obtener todos los cursos de instructores
export const obtenerTodosLosCursosInstru = async (req, res) => {
  try {
    const cursosInstru = await Curso_Instru.findAll();
    res.json(cursosInstru);
  } catch (error) {
    res.status(500).json({
      message: "Error al obtener los cursos de instructores",
      error: error.message,
    });
  }
};

// Controlador para obtener un curso de instructor por ID
export const obtenerCursoInstruPorID = async (req, res) => {
  const { id } = req.params;
  try {
    const cursoInstru = await Curso_Instru.findByPk(id);
    if (cursoInstru) {
      res.json(cursoInstru);
    } else {
      res.status(404).json({
        message: `No se encontró un curso de instructor con ID ${id}`,
      });
    }
  } catch (error) {
    res.status(500).json({
      message: "Error al obtener el curso de instructor",
      error: error.message,
    });
  }
};

// Controlador para crear un nuevo curso de instructor
export const crearCursoInstru = async (req, res) => {
  const nuevoCursoInstru = req.body;
  try {
    const cursoInstruCreado = await Curso_Instru.create(nuevoCursoInstru);
    res.status(201).json(cursoInstruCreado);
  } catch (error) {
    res.status(500).json({
      message: "Error al crear el curso de instructor",
      error: error.message,
    });
  }
};
import { Sequelize } from 'sequelize';


const miDb=new Sequelize("estudiantes", "root", "1234567890",{
    host: "localhost",
    dialect:"mysql",

})


export default miDb;

  
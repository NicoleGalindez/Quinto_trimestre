// import express from "express";
// import cors from "cors";
// import miDb   from "./bases/mibase.js";
// import apdzRoutes from "./rutas/mirutas.js";

// const app = express();
// app.use(cors());
// app.use(express.json());

// app.use('/aprendices', apdzRoutes)

// try{
//     await miDb.authenticate()
//     console.log("conexion exitosa");
// }
//     catch(error) {
//         console.log("error de conexion");
// }

// app.listen(8000, () => {
//     console.log("¡Lo logramos! Servidor en http://localhost:8000");
// });


import express from "express"
import cors from "cors"
import miDb from "./bases/mibase.js"
import router from "./rutas/mirutas.js"
const app = express()


app.use(cors())

app.use(express())

//para usar se utiliza use y para obtener es get
app.use("/aprendices",router)
try{
    await miDb.authenticate()
    console.log("conexion exitosa")
  
}
catch(error){
    console.log("error conexion")
}
//ahora tiene que escuchar un puerto estamos haciendo un colback
app.listen(8000,()=>{
    console.log("que bien lo logramos http://localhost:8000/")
})


app.use(cors())
app.use(express.json())
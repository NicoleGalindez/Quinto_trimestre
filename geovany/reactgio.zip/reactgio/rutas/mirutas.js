import express  from "express";

import { getAllApdz, getApdz,createApdz,updateApdz,deleteApdz } from "../controladores/micontrolador.js";

const router=express.Router()

router.get('/', getAllApdz)
router.get('/:id', getApdz)
router.post('/', createApdz)
router.put('/', updateApdz)
router.delete('/', deleteApdz)

export default router;
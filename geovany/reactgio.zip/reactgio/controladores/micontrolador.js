import mimodelo from "../modelo/mimodelo.js";     

// obtener todos los aprendices
export const getAllApdz= async(req, res)=>{      
    try{
        const Apdz= await mimodelo.findAll()
        res.json(Apdz)  
    }
    
    catch(error){
        res.json({message: error.message})
    }}

// obtener 1 aprendiz
export const getApdz = async (req,res)=>{ 
    try {
        const Apdz =await mimodelo.findAll({
    where:{id:req.params.id}
})
    res.json(Apdz[0]) 
    } catch (error) {
        res.json({message:error. message})
    }
}

// cerar un registro
export const createApdz = async (req,res)=>{ 
    try {
        await mimodelo.createApdz(req.body)
        res.json({"message": "Registro creado correctamente"});
    }catch (error) {
        res.json({message:error. message})}
    
}

// actualizar
export const updateApdz = async (req,res)=>{ 
    try {
        await mimodelo.updateApdz(req.body,{
            where:{id:req.params.id}
        })
        res.json({"message": " actualizado correctamente"});


    }catch (error) {
        res.json({message:error. message})}
    
}


//eliminar
export const deleteApdz = async (req,res)=>{ 
    try {
        await mimodelo.destroy(req.body,{
            where:{id:req.params.id}
        })
        res.json({"message": "Registro eliminado correctamente"});


    }catch (error) {
        res.json({message:error. message})}
    
}
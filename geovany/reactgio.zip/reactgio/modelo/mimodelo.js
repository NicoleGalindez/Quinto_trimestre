import miDb from "../bases/mibase.js";
import { DataTypes } from "sequelize";

const apdzModel = miDb.define("aprendizs", {
  id: { type: DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  nombre: { type: DataTypes.STRING },
  createAt:{ type: DataTypes.STRING},
  updateAt:{ type: DataTypes.STRING},

});

export default apdzModel;
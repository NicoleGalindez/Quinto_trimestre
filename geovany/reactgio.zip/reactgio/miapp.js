import express from "express";
import cors from "cors";
import miDb   from "./bases/mibase.js";
import apdzRoutes from "./rutas/mirutas.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use('/aprendices', apdzRoutes)

try{
    await miDb.authenticate()
    console.log("conexion exitosa");
}
    catch(error) {
        console.log("error de conexion");
}

app.listen(8000, () => {
    console.log("¡Lo logramos! Servidor en http://localhost:8000");
});


